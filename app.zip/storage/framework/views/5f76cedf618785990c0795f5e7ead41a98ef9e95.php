
        <!-- Begin Hiraola's Breadcrumb Area -->
        <div class="breadcrumb-area">
            <div class="container">
                <div class="breadcrumb-content">
                    <h2>Избранное</h2>
                    <ul>
                        <li><a href="index.html">Home</a></li>
                        <li class="active">Cart</li>
                    </ul>
                </div>
            </div>
        </div>
        <!-- Hiraola's Breadcrumb Area End Here -->
        <!-- Begin Hiraola's Cart Area -->
        <div class="hiraola-cart-area">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <form action="javascript:void(0)">
                            <div class="table-content table-responsive">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th class="hiraola-product-remove">Удалить</th>
                                            <th class="hiraola-product-thumbnail">Картинка</th>
                                            <th class="cart-product-name">Название</th>
                                            <th class="hiraola-product-subtotal">Цена</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $PageInfo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td class="hiraola-product-remove"><a href="javascript:void(0)" onclick=""><i class="fa fa-trash" title="Remove"></i></a></td>

                                                <td class="hiraola-product-thumbnail"><a href="javascript:void(0)"><img src="assets/images/product/small-size/2-1.jpg" alt="Hiraola's Cart Thumbnail"></a></td>
                                                <td class="hiraola-product-name"><a href="javascript:void(0)"><?php echo e($result->name); ?></a></td>
                                                <td class="product-subtotal"><span class="amount" id="value_amunt"><?php echo e($result->price); ?>₴</span></td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div> 
                            
                            <?php echo csrf_field(); ?>
                            <script>
                                function coupun(){
                                    let coupune = document.getElementById('coupon_code').value;
                                    let csrf = document.getElementsByName('_token')[0].value;
                                    $.ajax({
                                        type: 'POST',
                                        url: '<?php echo e(Route("GetCoupon")); ?>',
                                        dataType: 'json',
                                        data: 'coupone=' + coupune + '&_token=' + csrf,
                                        success: function(data){
                                            if(data.status == true){
                                                location.reload();
                                            } else {
                                                alert(data.error);
                                            }
                                        }
                                    });
                                }
                                function DeleteProduct(id){
                                    let csrf = document.getElementsByName('_token')[0].value;
                                    $.ajax({
                                        type: 'POST',
                                        url: '<?php echo e(Route("DeleteProduct")); ?>',
                                        dataType: 'json',
                                        data: 'id=' + id + '&_token=' + csrf,
                                        success: function(data){
                                            if(data.status == true){
                                                location.reload();
                                            } else {
                                                alert(data.error);
                                            }
                                        }
                                    });
                                }
                            </script>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <!-- Hiraola's Cart Area End Here --><?php /**PATH /var/www/ch6bcde14c/www/todase.com.ua/resources/views/wishlist/index.blade.php ENDPATH**/ ?>