                    <div class="col grid-full order-md-1 order-lg-2">
                        <div class="hiraola-slider_area">
                            <div class="main-slider">
                                <?php $__currentLoopData = $PageInfo['first_banners']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <!-- Begin Single Slide Area -->
                                    <div class="single-slide animation-style-01 bg-1">
                                        <div class="container">
                                            <div class="slider-content">
                                                <h5><?php if($result->name_action != null): ?> <?php echo e($result->name_action); ?> <?php else: ?> Покупай зараз! <?php endif; ?></h5>
                                                <h2><?php echo e($result->name); ?></h2>
                                                <h3>За вигідною ціною</h3>
                                                <h4>Всього <span><?php echo e($result->price); ?>₴</span></h4>
                                                <div class="hiraola-btn-ps_left slide-btn">
                                                    <a class="hiraola-btn" href="<?php echo e(Route('ProductPage', ['page' => 'product', 'product' => $result->id])); ?>">До кошика</a>
                                                </div>
                                            </div>
                                            <div class="slider-progress"></div>
                                        </div>
                                    </div>
                                    <!-- Single Slide Area End Here -->
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>



    <?php if(count($PageInfo['new_product']) > 0): ?>
        <!-- Begin Hiraola's Product Area -->
        <div class="hiraola-product_area">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="hiraola-section_title">
                            <h4>Нові товари</h4>
                        </div>
                    </div>
                    <div class="col-lg-12">
                        <div class="hiraola-product_slider">
                            <?php $__currentLoopData = $PageInfo['new_product']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $rating = $result['rating'];
                                    $result = $result['info'];
                                ?>
                                <!-- Begin Hiraola's Slide Item Area -->
                                <div class="slide-item">
                                    <div class="single_product">
                                        <div class="product-img">
                                            <a href="<?php echo e(Route('ProductPage', ['page' => 'product', 'product' => $result->id])); ?>">
                                                <?php
                                                    $images = json_decode($result->pictures);
                                                ?>
                                                <?php if(count($images) > 0): ?>
                                                    <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <img class="primary-img" src="<?php echo e($image->name); ?>" alt="<?php echo e($result->name); ?>">
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php else: ?>
                                                    <img class="primary-img" src="assets/images/product/medium-size/1-1.jpg" alt="Hiraola's Product Image">
                                                <?php endif; ?>

                                            </a>
                                            <span class="sticker">New</span>
                                        </div>
                                        <div class="hiraola-product_content">
                                            <div class="product-desc_info">
                                                <h6><a class="product-name" href="<?php echo e(Route('ProductPage', ['page' => 'product', 'product' => $result->id])); ?>"><?php echo e($result->name); ?></a></h6>
                                                <div class="price-box">
                                                    <span class="new-price"><?php echo e($result->price); ?>₴</span>
                                                </div>
                                                <div class="additional-add_action">
                                                    <ul>
                                                        <li><a class="hiraola-add_compare " <?php if($CheckAuth['status'] == false): ?> href=" <?php echo e(Route('Page', ['page' => 'wishlist'])); ?>" <?php else: ?> onclick="AddToWish(<?php echo e($result->id); ?>)" <?php endif; ?> data-toggle="tooltip" data-placement="top" title="Добавить в избранное"><i class="ion-android-favorite-outline"></i></a></li>
                                                    </ul>
                                                </div>
                                                <div class="rating-box">
                                                    <ul>
                                                        <?php for($i = 0; $i < 5; $i++): ?>
                                                            <?php if($i < $rating): ?>
                                                                <li><i class="fa fa-star-of-david"></i></li>
                                                            <?php else: ?>
                                                                <li class="silver-color"><i class="fa fa-star-of-david"></i></li>
                                                            <?php endif; ?>
                                                        <?php endfor; ?>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- Hiraola's Slide Item Area End Here -->
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Hiraola's Product Area End Here -->
    <?php endif; ?>
    <?php echo csrf_field(); ?>
    <script>
        function AddToWish(id){
            let csrf = document.getElementsByName('_token')[0].value;
            $.ajax({
                type: 'POST',
                url: '<?php echo e(Route("AddToWish")); ?>',
                dataType: 'json',
                data: 'id=' + id + '&_token=' + csrf,
                success: function(data){
                    if(data.status == true){
                        location.reload();
                    } else {
                        alert(data.error);
                    }
                }
            });
        }
    </script>

    <?php if($PageInfo['discount'] != null): ?>
        <div class="static-banner_area">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="static-banner-image"></div>
                        <div class="static-banner-content">
                            <?php
                                $percent = (100 - ($PageInfo['discount']->discount * 100) / $PageInfo['discount']->price);
                            ?>
                            <p><span>-<?php echo e($percent); ?>% знижки </span> тільки зараз</p>
                            <h2><?php echo e($PageInfo['discount']->name); ?></h2>
                            <p class="schedule">
                                Starting at
                                <span> <?php echo e($PageInfo['discount']->discount); ?>₴</span>
                            </p>
                            <div class="hiraola-btn-ps_left">
                                <a href="<?php echo e(Route('ProductPage', ['page' => 'product', 'product' => $result->id])); ?>" class="hiraola-btn">До кошику</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?>


    <?php if(count($PageInfo['out']) > 0): ?>
        <!-- Begin Hiraola's Product Tab Area -->
        <div class="hiraola-product-tab_area-2">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="product-tab">
                            <div class="hiraola-tab_title">
                                <h4>Вже закінчуються</h4>
                            </div>
                        </div>
                        <div class="tab-content hiraola-tab_content">
                            <div id="necklaces" class="tab-pane active show" role="tabpanel">
                                <div class="hiraola-product-tab_slider-2">
                                <?php $__currentLoopData = $PageInfo['out']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        $rating = $result['rating'];
                                        $result = $result['info'];
                                    ?>
                                    <!-- Begin Hiraola's Slide Item Area -->
                                    <div class="slide-item">
                                        <div class="single_product">
                                            <div class="product-img">
                                                <a href="<?php echo e(Route('ProductPage', ['page' => 'product', 'product' => $result->id])); ?>">
                                                    <?php
                                                        $images = json_decode($result->pictures);
                                                    ?>
                                                    <?php if(count($images) > 0): ?>
                                                        <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <img class="primary-img" src="<?php echo e($image->name); ?>" alt="<?php echo e($result->name); ?>">
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php else: ?>
                                                        <img class="primary-img" src="assets/images/product/medium-size/1-1.jpg" alt="Hiraola's Product Image">
                                                    <?php endif; ?>

                                                </a>
                                            </div>
                                            <div class="hiraola-product_content">
                                                <div class="product-desc_info">
                                                    <h6><a class="product-name" href="<?php echo e(Route('ProductPage', ['page' => 'product', 'product' => $result->id])); ?>"><?php echo e($result->name); ?></a></h6>
                                                    <div class="price-box">
                                                        <span class="new-price"><?php echo e($result->price); ?>₴</span>
                                                    </div>
                                                    <div class="additional-add_action">
                                                        <ul>
                                                            <li><a class="hiraola-add_compare" <?php if($CheckAuth['status'] == false): ?> href=" <?php echo e(Route('Page', ['page' => 'wishlist'])); ?>" <?php else: ?> onclick="AddToWish(<?php echo e($result->id); ?>)" <?php endif; ?> data-toggle="tooltip" data-placement="top" title="Добавить в избранное"><i class="ion-android-favorite-outline"></i></a></li>
                                                        </ul>
                                                    </div>
                                                    <div class="rating-box">
                                                        <ul>
                                                            <?php for($i = 0; $i < 5; $i++): ?>
                                                                <?php if($i < $rating): ?>
                                                                    <li><i class="fa fa-star-of-david"></i></li>
                                                                <?php else: ?>
                                                                    <li class="silver-color"><i class="fa fa-star-of-david"></i></li>
                                                                <?php endif; ?>
                                                            <?php endfor; ?>
                                                        </ul>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- Hiraola's Slide Item Area End Here -->
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>


                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Hiraola's Product Tab Area End Here -->
    <?php endif; ?>





<?php /**PATH /var/www/ch6bcde14c/www/todase.com.ua/resources/views/main/index.blade.php ENDPATH**/ ?>