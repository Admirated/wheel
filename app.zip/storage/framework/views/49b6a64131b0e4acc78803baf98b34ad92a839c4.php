<?php echo $__env->make('head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<body class="template-color-1">

    <div class="main-wrapper">

        <!-- Begin Loading Area -->
        <div class="loading">
            <div class="text-center middle">
                <div class="lds-ellipsis">
                    <div></div>
                    <div></div>
                    <div></div>
                    <div></div>
                </div>
            </div>
        </div>
        <!-- Loading Area End Here -->

        <!-- Begin Hiraola's Header Main Area -->
        <?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- Hiraola's Header Main Area End Here -->


        <!-- Begin Hiraola's Breadcrumb Area -->
        <div class="breadcrumb-area">
            <div class="container">
                <div class="breadcrumb-content">
                    <h2>Other</h2>
                    <ul>
                        <li><a href="index.html">Home</a></li>
                        <li class="active">Login & Register</li>
                    </ul>
                </div>
            </div>
        </div>
        <!-- Hiraola's Breadcrumb Area End Here -->
        <!-- Begin Hiraola's Login Register Area -->
        <div class="hiraola-login-register_area">
            <div class="container">
                <div class="row">
                    <div class="col-sm-12 col-md-12 col-xs-12 col-lg-6">
                        <!-- Login Form s-->
                        <form id="auth">
                            <div class="login-form">
                                <h4 class="login-title">Login</h4>
                                <div class="row">
                                    <?php echo csrf_field(); ?>
                                    <div class="col-md-12">
                                        <label>Email*</label>
                                        <input type="email" name="email" placeholder="Email">
                                    </div>
                                    <div class="col-md-12">
                                        <label>Пароль</label>
                                        <input type="password" name="password" placeholder="Пароль">
                                    </div>

                                    <div class="col-md-12">
                                        <button class="hiraola-login_btn">Войти</button>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                    <div class="col-sm-12 col-md-12 col-lg-6 col-xs-12">
                        <form id="register">
                            <div class="login-form">
                                <h4 class="login-title">Register</h4>
                                <div class="row">
                                    <?php echo csrf_field(); ?>
                                    <div class="col-md-12">
                                        <label>ФИО*</label>
                                        <input type="text" name="full_name" placeholder="ФИО">
                                    </div>
                                    <div class="col-md-12">
                                        <label>Email*</label>
                                        <input type="email" name="email" placeholder="Email">
                                    </div>
                                    <div class="col-md-6">
                                        <label>Пароль</label>
                                        <input type="password" name="password" placeholder="Пароль">
                                    </div>
                                    <div class="col-md-6">
                                        <label>Повторите пароль</label>
                                        <input type="password" name="repassword" placeholder="Повторите пароль">
                                    </div>
                                    <div class="col-12">
                                        <button class="hiraola-register_btn">Регистрация</button>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>

        <script>
            $("#register").submit(function(event) {
                event.preventDefault();
                $.ajax({
                    url: "<?php echo e(Route('Register')); ?>",
                    method: 'post',
                    dataType: 'json',
                    data: $(this).serialize(),
                    success: function(data){
                        if(data.status == true){
                            alert("Вы успешно зарегестрировались! Подтвердите вашу электронную почту");
                        } else {
                            alert(data.error);
                        }
                    }
                });
            });

            $("#auth").submit(function(event) {
                event.preventDefault();
                $.ajax({
                    url: "<?php echo e(Route('Auth')); ?>",
                    method: 'post',
                    dataType: 'json',
                    data: $(this).serialize(),
                    success: function(data){
                        if(data.status == true){
                            alert("Ура");
                        } else {
                            alert(data.error);
                        }
                    }
                });
            });
        </script>
        <!-- Hiraola's Login Register Area  End Here -->
        <!-- Begin Hiraola's Footer Area -->
        <?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- Hiraola's Footer Area End Here -->

    </div>

    <!-- JS
============================================ -->

    <!-- jQuery JS -->
    
    <script src="assets/js/vendor/jquery-1.12.4.min.js"></script>
    <!-- Modernizer JS -->
    <script src="assets/js/vendor/modernizr-2.8.3.min.js"></script>
    <!-- Popper JS -->
    <script src="assets/js/vendor/popper.min.js"></script>
    <!-- Bootstrap JS -->
    <script src="assets/js/vendor/bootstrap.min.js"></script>

    <!-- Slick Slider JS -->
    <script src="assets/js/plugins/slick.min.js"></script>
    <!-- Countdown JS -->
    <script src="assets/js/plugins/countdown.js"></script>
    <!-- Barrating JS -->
    <script src="assets/js/plugins/jquery.barrating.min.js"></script>
    <!-- Counterup JS -->
    <script src="assets/js/plugins/jquery.counterup.js"></script>
    <!-- Nice Select JS -->
    <script src="assets/js/plugins/jquery.nice-select.js"></script>
    <!-- Sticky Sidebar JS -->
    <script src="assets/js/plugins/jquery.sticky-sidebar.js"></script>
    <!-- Jquery-ui JS -->
    <script src="assets/js/plugins/jquery-ui.min.js"></script>
    <script src="assets/js/plugins/jquery.ui.touch-punch.min.js"></script>
    <!-- Lightgallery JS -->
    <script src="assets/js/plugins/lightgallery.min.js"></script>
    <!-- Scroll Top JS -->
    <script src="assets/js/plugins/scroll-top.js"></script>
    <!-- Theia Sticky Sidebar JS -->
    <script src="assets/js/plugins/theia-sticky-sidebar.min.js"></script>
    <!-- Waypoints JS -->
    <script src="assets/js/plugins/waypoints.min.js"></script>
    <!-- Instafeed JS -->
    <script src="assets/js/plugins/instafeed.min.js"></script>
    <!-- Instafeed JS -->
    <script src="assets/js/plugins/jquery.elevateZoom-3.0.8.min.js"></script>

    <!-- Vendor & Plugins JS (Please remove the comment from below vendor.min.js & plugins.min.js for better website load performance and remove js files from avobe) -->
    <!--
<script src="assets/js/vendor/vendor.min.js"></script>
<script src="assets/js/plugins/plugins.min.js"></script>
-->

    <!-- Main JS -->
    <script src="assets/js/main.js"></script>

</body>

</html><?php /**PATH /var/www/ch6bcde14c/www/todase.com.ua/resources/views/login.blade.php ENDPATH**/ ?>