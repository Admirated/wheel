<?php echo $__env->make('head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<body class="template-color-1">

    <div class="main-wrapper">

        <!-- Begin Loading Area -->
        <div class="loading">
            <div class="text-center middle">
                <div class="lds-ellipsis">
                    <div></div>
                    <div></div>
                    <div></div>
                    <div></div>
                </div>
            </div>
        </div>
        <!-- Loading Area End Here -->


        <!-- Begin Hiraola's Header Main Area -->
        <?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- Hiraola's Header Main Area End Here -->


        <?php if($page == "main"): ?>
            <?php echo $__env->make('left_menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>
        <?php echo $__env->make($page . "/index", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;



        <!-- Begin Hiraola's Shipping Area -->
        <div class="hiraola-shipping_area">
            <div class="container">
                <div class="shipping-nav">
                    <div class="row">
                        <div class="col-lg-3 col-md-6">
                            <div class="shipping-item">
                                <div class="shipping-icon">
                                    <img src="<?php echo e(asset('assets/images/shipping-icon/1.png')); ?>" alt="Hiraola's Shipping Icon">
                                </div>
                                <div class="shipping-content">
                                    <h6>Free Uk Standard Delivery</h6>
                                    <p>Designated day delivery</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-6">
                            <div class="shipping-item">
                                <div class="shipping-icon">
                                    <img src="<?php echo e(asset('assets/images/shipping-icon/2.png')); ?>" alt="Hiraola's Shipping Icon">
                                </div>
                                <div class="shipping-content">
                                    <h6>Freshyly Prepared Ingredients</h6>
                                    <p>Made for your delivery date</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-6">
                            <div class="shipping-item">
                                <div class="shipping-icon">
                                    <img src="<?php echo e(asset('assets/images/shipping-icon/3.png')); ?>" alt="Hiraola's Shipping Icon">
                                </div>
                                <div class="shipping-content">
                                    <h6>98% Of Anta Clients</h6>
                                    <p>Reach their personal goals set</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-6">
                            <div class="shipping-item">
                                <div class="shipping-icon">
                                    <img src="<?php echo e(asset('assets/images/shipping-icon/4.png')); ?>" alt="Hiraola's Shipping Icon">
                                </div>
                                <div class="shipping-content">
                                    <h6>Winner Of 15 Awards</h6>
                                    <p>Healthy food and drink 2019</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Hiraola's Shipping Area End Here -->


        <!-- Begin Hiraola's Footer Area -->
        <?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- Hiraola's Footer Area End Here -->

    </div>

    <!-- JS
============================================ -->

    <!-- jQuery JS -->
    <script src="<?php echo e(asset('assets/js/vendor/jquery-1.12.4.min.js')); ?>"></script>
    <!-- Modernizer JS -->
    <script src="<?php echo e(asset('assets/js/vendor/modernizr-2.8.3.min.js')); ?>"></script>
    <!-- Popper JS -->
    <script src="<?php echo e(asset('assets/js/vendor/popper.min.js')); ?>"></script>
    <!-- Bootstrap JS -->
    <script src="<?php echo e(asset('assets/js/vendor/bootstrap.min.js')); ?>"></script>

    <!-- Slick Slider JS -->
    <script src="<?php echo e(asset('assets/js/plugins/slick.min.js')); ?>"></script>
    <!-- Countdown JS -->
    <script src="<?php echo e(asset('assets/js/plugins/countdown.js')); ?>"></script>
    <!-- Barrating JS -->
    <script src="<?php echo e(asset('assets/js/plugins/jquery.barrating.min.js')); ?>"></script>
    <!-- Counterup JS -->
    <script src="<?php echo e(asset('assets/js/plugins/jquery.counterup.js')); ?>"></script>
    <!-- Nice Select JS -->
    <script src="<?php echo e(asset('assets/js/plugins/jquery.nice-select.js')); ?>"></script>
    <!-- Sticky Sidebar JS -->
    <script src="<?php echo e(asset('assets/js/plugins/jquery.sticky-sidebar.js')); ?>"></script>
    <!-- Jquery-ui JS -->
    <script src="<?php echo e(asset('assets/js/plugins/jquery-ui.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/plugins/jquery.ui.touch-punch.min.js')); ?>"></script>
    <!-- Lightgallery JS -->
    <script src="<?php echo e(asset('assets/js/plugins/lightgallery.min.js')); ?>"></script>
    <!-- Scroll Top JS -->
    <script src="<?php echo e(asset('assets/js/plugins/scroll-top.js')); ?>"></script>
    <!-- Theia Sticky Sidebar JS -->
    <script src="<?php echo e(asset('assets/js/plugins/theia-sticky-sidebar.min.js')); ?>"></script>
    <!-- Waypoints JS -->
    <script src="<?php echo e(asset('assets/js/plugins/waypoints.min.js')); ?>"></script>
    <!-- Instafeed JS -->
    <script src="<?php echo e(asset('assets/js/plugins/instafeed.min.js')); ?>"></script>
    <!-- Instafeed JS -->
    <script src="<?php echo e(asset('assets/js/plugins/jquery.elevateZoom-3.0.8.min.js')); ?>"></script>

    <!-- Vendor & Plugins JS (Please remove the comment from below vendor.min.js & plugins.min.js for better website load performance and remove js files from avobe) -->
    <!--
<script src="assets/js/vendor/vendor.min.js"></script>
<script src="assets/js/plugins/plugins.min.js"></script>
-->

    <!-- Main JS -->
    <script src="<?php echo e(asset('assets/js/main.js')); ?>"></script>

</body>

</html><?php /**PATH /var/www/ch6bcde14c/www/todase.com.ua/resources/views/main.blade.php ENDPATH**/ ?>