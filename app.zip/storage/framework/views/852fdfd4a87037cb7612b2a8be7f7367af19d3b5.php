
        <!-- Begin Hiraola's Breadcrumb Area -->
        <div class="breadcrumb-area">
            <div class="container">
                <div class="breadcrumb-content">
                    <h2>Other</h2>
                    <ul>
                        <li><a href="index.html">Home</a></li>
                        <li class="active">Cart</li>
                    </ul>
                </div>
            </div>
        </div>
        <!-- Hiraola's Breadcrumb Area End Here -->
        <!-- Begin Hiraola's Cart Area -->
        <div class="hiraola-cart-area">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <form action="javascript:void(0)">
                            <div class="table-content table-responsive">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th class="hiraola-product-remove">Удалить</th>
                                            <th class="hiraola-product-thumbnail">Картинка</th>
                                            <th class="cart-product-name">Название</th>
                                            <th>Количество</th>
                                            <th class="hiraola-product-subtotal">Цена</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                            $all_sum = 0;
                                            $cupon = $cart['cupon'];
                                        ?>
                                        <?php $__currentLoopData = $cart['product']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>   
                                            <?php
                                                $count = $result['count'];
                                                $result = $result['info'];
                                            ?>
                                            <tr>
                                                <td class="hiraola-product-remove"><a href="javascript:void(0)" onclick="DeleteProduct(<?php echo e($result->id); ?>)"><i class="fa fa-trash"
                                                    title="Remove"></i></a></td>
                                                <?php
                                                    $image = json_decode($result->pictures);
                                                ?>
                                                <td class="hiraola-product-thumbnail"><a href="javascript:void(0)"><img src="<?php if(count($image) > 0): ?> <?php echo e($image[0]->url); ?> <?php else: ?> assets/images/product/small-size/2-1.jpg <?php endif; ?>" alt="Hiraola's Cart Thumbnail"></a></td>
                                                <td class="hiraola-product-name"><a href="javascript:void(0)"><?php echo e($result->name); ?></a></td>
                                                <?php
                                                    $price = 0;
                                                    if($result->discount != 0){
                                                        $price = $result->discount;
                                                    } else {
                                                        $price = $result->price;
                                                    }
                                                    if($cupon != null){
                                                        $price = $price - (($price * $cupon->percent) / 100);
                                                    }
                                                    $all_sum += $count*$price;
                                                ?>
                                                <td><?php echo e($count); ?></td>
                                                <td class="product-subtotal"><span class="amount" id="value_amunt"><?php echo $price * $count; ?>₴</span></td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div> 
                            <div class="row">
                                <div class="col-12">
                                    <div class="coupon-all">
                                        <div class="coupon" id="coupon">
                                            <?php if($cupon == null): ?>
                                                <input id="coupon_code" class="input-text" name="coupon_code"  value="" placeholder="Купон" type="text">
                                                <input class="button" name="apply_coupon" onclick="coupun()"  value="Использовать купон" type="submit">
                                            <?php else: ?>
                                                <p>У вас уже использован купон - <?php echo e($cupon->percent); ?>% скидки</p>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php echo csrf_field(); ?>
                            <script>
                                function coupun(){
                                    let coupune = document.getElementById('coupon_code').value;
                                    let csrf = document.getElementsByName('_token')[0].value;
                                    $.ajax({
                                        type: 'POST',
                                        url: '<?php echo e(Route("GetCoupon")); ?>',
                                        dataType: 'json',
                                        data: 'coupone=' + coupune + '&_token=' + csrf,
                                        success: function(data){
                                            if(data.status == true){
                                                location.reload();
                                            } else {
                                                alert(data.error);
                                            }
                                        }
                                    });
                                }
                                function DeleteProduct(id){
                                    let csrf = document.getElementsByName('_token')[0].value;
                                    $.ajax({
                                        type: 'POST',
                                        url: '<?php echo e(Route("DeleteProduct")); ?>',
                                        dataType: 'json',
                                        data: 'id=' + id + '&_token=' + csrf,
                                        success: function(data){
                                            if(data.status == true){
                                                location.reload();
                                            } else {
                                                alert(data.error);
                                            }
                                        }
                                    });
                                }
                            </script>
                            <div class="row">
                                <div class="col-md-5 ml-auto">
                                    <div class="cart-page-total">
                                        <h2>Итог</h2>
                                        <ul>
                                            <li>Стоимость <span id="value_total"><?php echo e($all_sum); ?>₴</span></li>
                                            <li>Со скидкой <span id="value_subtotal"><?php echo e($all_sum); ?>₴</span></li>
                                        </ul>
                                        <a href="javascript:void(0)">Перейти к оплате</a>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <!-- Hiraola's Cart Area End Here --><?php /**PATH /var/www/ch6bcde14c/www/todase.com.ua/resources/views/cart/index.blade.php ENDPATH**/ ?>