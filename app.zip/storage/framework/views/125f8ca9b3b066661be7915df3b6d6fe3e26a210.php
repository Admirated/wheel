<div id="logo_container"  class="container">
    <div  class="logo_container" style="text-align: center">
        <img style="height: 133px; width: 133px" src="<?php echo e(asset('assets/images/RegLogo.png')); ?>">
        <h3 style="font-family: 'SF Pro Display', sans-serif;font-style: normal;font-weight: 600;font-size: 25px;line-height: 30px;margin-top: 20px;/* identical to box height */color: #000000;">Be Better</h3>
        <p style="font-family: 'Roboto',sans-serif;
font-style: normal;
font-weight: normal;
font-size: 13px;
line-height: 15px;

color: #333333;">Версия 104 (5.1)</p>
    </div>

</div>
<div class="container" style="display: flex; justify-content: center; text-align: center; flex-direction: column">
    <p  style="color:#2F80ED;">Лицензионное соглашение</p>
    <p style="font-family: 'Roboto',sans-serif;
font-style: normal;
font-weight: normal;
font-size: 13px;
line-height: 15px;

/* Серый для текста */

color: #7C7C7C;">© 2010 — 2021 ООО “Be better”</p>
</div>
<?php /**PATH /home/vprokit/app.vprockit.ru/resources/views/Version/index.blade.php ENDPATH**/ ?>