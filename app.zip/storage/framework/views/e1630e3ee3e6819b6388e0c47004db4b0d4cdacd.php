<!DOCTYPE html>
<html lang="en">
<head>
    <?php echo $__env->make('head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>
<body>
    <?php if($page != "ChangeProfile" && $page != "MakeFirstQuest"): ?>
        <div class="container ">
            <div class="navigate_wrapper row justify-content-between left">
                <div style="margin-top: 15px;" class="back_block">
                    <button class="back-button" onclick="window.history.back()" style="padding: 0;"><img width="22" height="22" style="max-width: 24px; max-height: 24px;" src="<?php echo e(asset('assets/images/corner-up-left.png')); ?>"></button>
                </div>
                <div class="page_title_block">
                    <h1><?php echo e($title); ?></h1>
                    <p>Меню</p>
                </div>
                <div style="margin-top: 15px;" class="menu_block">
                    <img style="max-width: 20px; max-height: 4px" src="<?php echo e(asset('assets/images/title_dots.png')); ?>">
                </div>
            </div>
        </div>
    <?php endif; ?>
<!-- Header part end-->
    <?php echo $__env->make($page . '/index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <?php if($page != "ChangeProfile" && $page != "MakeFirstQuest"): ?>
        <footer class="footer">
            <div class="row justify-content-around">
                <a href="<?php echo e(Route('page', ['page' => 'BalanceWheel'])); ?>"><img class="footer_atribute" src="<?php echo e(asset('assets/images/first_footer_atribute.png')); ?>"></a>

                <a href="<?php echo e(Route('page', ['page' => 'RedactProfile'])); ?>"><img class="footer_atribute" src="<?php echo e(asset('assets/images/third_footer_atribute.png')); ?>"></a>
                <a href="<?php echo e(Route('page', ['page' => 'index'])); ?>"><img class="footer_atribute" src="<?php echo e(asset('assets/images/fourth_footer_atribute.png')); ?>"></a>
            </div>
        </footer>
    <?php endif; ?>
        <script>

            async function ts(url,method,data){
                try {
                    const response = await fetch(url, {
                        method: method,
                        body: data
                    });
                    const json = await response.json();
                    return json;
                } catch (error) {
                    console.error('Error toServer:', error);
                    return error;
                }
            }

        </script>


<?php /**PATH /home/vprokit/app.vprockit.ru/resources/views/main.blade.php ENDPATH**/ ?>