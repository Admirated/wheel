

        <!-- Begin Hiraola's Breadcrumb Area -->
        <div class="breadcrumb-area">
            <div class="container">
                <div class="breadcrumb-content">
                    <h2>Single Product Type</h2>
                    <ul>
                        <li><a href="index.html">Home</a></li>
                        <li class="active">Single Product Affiliate</li>
                    </ul>
                </div>
            </div>
        </div>
        <!-- Hiraola's Breadcrumb Area End Here -->





        <!-- Begin Hiraola's Single Product Affiliate Area -->
        <div class="sp-area sp-affiliate_area">
            <div class="container">
                <div class="sp-nav">
                    <div class="row">
                        <div class="col-lg-5 col-md-5">
                            <div class="sp-img_area">
                                <?php
                                    $product = $PageInfo['product'];
                                    $rating = $PageInfo['rating'];
                                    $pictures = $product->pictures;
                                    $pictures = json_decode($pictures);
                                ?>
                                <div class="zoompro-border">
                                    <img class="zoompro" src="<?php if($pictures == null): ?> <?php echo e(asset('assets/images/single-product/large-size/1.jpg')); ?> <?php else: ?> <?php echo e($pictures[0]); ?> <?php endif; ?>" data-zoom-image="<?php if($pictures == null): ?> <?php echo e(asset('assets/images/single-product/large-size/1.jpg')); ?> <?php else: ?> <?php echo e($pictures[0]); ?> <?php endif; ?>" alt="" />
                                </div>
                                <div id="gallery" class="sp-img_slider sp-imagezoom">
                                    <?php $__currentLoopData = $pictures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <a class="active" data-image="<?php echo e($result); ?>" data-zoom-image="<?php echo e($result); ?>">
                                            <img src="<?php echo e($result); ?>" alt="">
                                        </a>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-7 col-md-7">
                            <div class="sp-content">
                                <div class="sp-heading">
                                    <h5><a href="#"><?php echo e($product->name); ?></a></h5>
                                </div>
                                <span class="reference">Бренд: <?php echo e($product->reference); ?></span>
                                <div class="rating-box">
                                    <ul>
                                        <?php for($i = 0; $i < 5; $i++): ?>
                                            <?php if($i < $rating): ?>
                                                <li><i class="fa fa-star-of-david"></i></li>
                                            <?php else: ?> 
                                                <li class="silver-color"><i class="fa fa-star-of-david"></i></li>
                                            <?php endif; ?>
                                        <?php endfor; ?>
                                    </ul>
                                </div>
                                <div class="sp-essential_stuff">
                                    <ul>
                                        <li>Цена: <a href="javascript:void(0)"><span><?php if($product->discount == 0): ?> <?php echo e($product->price); ?> <?php else: ?> <?php echo e($product->discount); ?> (СКИДКА) <?php endif; ?></span></a></li>
                                        <li>Бренд <a href="javascript:void(0)"><?php echo e($product->brand); ?></a></li>
                                        <li>Артикул: <a href="javascript:void(0)"><?php echo e($product->articul); ?></a></li>
                                        <li>На складе: <a href="javascript:void(0)"><?php echo e($product->count); ?></a></li>
                                    </ul>
                                </div>
                                <div class="qty-btn_area">
                                    <a href="javascrip:void(0)" class="qty-buy_btn">В корзину</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Hiraola's Single Product Affiliate Area End Here -->






        <!-- Begin Hiraola's Single Product Tab Area -->
        <div class="hiraola-product-tab_area-2 sp-product-tab_area">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="sp-product-tab_nav ">
                            <div class="product-tab">
                                <ul class="nav product-menu">
                                    <li><a class="active" data-toggle="tab" href="#description"><span>Описание</span></a></li>
                                    <?php if($product->specifications != null): ?>
                                        <li><a data-toggle="tab" href="#specification"><span>Характеристики</span></a></li>
                                    <?php endif; ?>
                                    <li><a data-toggle="tab" href="#reviews"><span>Отзывы (<?php echo count($PageInfo['review']); ?>)</span></a></li>
                                </ul>
                            </div>
                            <div class="tab-content hiraola-tab_content">
                                <div id="description" class="tab-pane active show" role="tabpanel">
                                    <div class="product-description">
                                        <ul>

                                            <li>
                                                <strong><?php echo e($product->name); ?></strong>
                                                <span><?php echo e($product->descript); ?></span>
                                            </li>

                                        </ul>
                                    </div>
                                </div>
                                <?php if($product->specifications != null): ?>
                                    <div id="specification" class="tab-pane" role="tabpanel">
                                        <table class="table table-bordered specification-inner_stuff">
                                            <?php
                                                $specifications = $product->specifications;
                                                $specifications = json_decode($specifications);
                                            ?>
                                            <?php $__currentLoopData = $specifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tbody>
                                                    <tr>
                                                        <td colspan="1"><strong><?php echo e($result->name); ?></strong></td>
                                                    </tr>
                                                </tbody>
                                                <tbody>
                                                    <tr>
                                                        <td><?php echo e($result->value); ?></td>
                                                    </tr>
                                                </tbody>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </table>
                                    </div>
                                <?php endif; ?>
                                <div id="reviews" class="tab-pane" role="tabpanel">
                                    <div class="tab-pane active" id="tab-review">
                                        <form class="form-horizontal" id="form-review">
                                            <div id="review">
                                                <table class="table table-striped table-bordered">
                                                    <?php $__currentLoopData = $PageInfo['review']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <tbody>
                                                            <tr>
                                                                <td style="width: 50%;"><strong><?php echo e($result['full_name']); ?></strong></td>
                                                                <td class="text-right"><?php echo e($result['created_at']); ?></td>
                                                            </tr>
                                                            <tr>
                                                                <td colspan="2">
                                                                    <p><?php echo e($result['review']); ?></p>
                                                                    <div class="rating-box">
                                                                        <ul>
                                                                            <?php for($i = 0; $i < 5; $i++): ?>
                                                                                <?php if($i < $result['mark']): ?>
                                                                                    <li><i class="fa fa-star-of-david"></i></li>
                                                                                <?php else: ?> 
                                                                                    <li class="silver-color"><i class="fa fa-star-of-david"></i></li>
                                                                                <?php endif; ?>
                                                                            <?php endfor; ?>
                                                                        </ul>
                                                                    </div>
                                                                </td>
                                                            </tr>
                                                        </tbody>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </table>
                                            </div>
                                            <h2>Напишите свой отзыв о данном товаре</h2>
                                            <div class="form-group required second-child">
                                                <div class="col-sm-12 p-0">
                                                    <label class="control-label">Ваш отзыв</label>
                                                    <textarea class="review-textarea" name="con_message" id="con_message"></textarea>
                                                </div>
                                            </div>
                                            <div class="form-group last-child required">
                                                <div class="col-sm-12 p-0">
                                                    <div class="your-opinion">
                                                        <label>Ваша оценка</label>
                                                        <span>
                                                        <select class="star-rating">
                                                            <option value="1">1</option>
                                                            <option value="2">2</option>
                                                            <option value="3">3</option>
                                                            <option value="4">4</option>
                                                            <option value="5">5</option>
                                                        </select>
                                                    </span>
                                                    </div>
                                                </div>
                                                <div class="hiraola-btn-ps_right">
                                                    <a href="javascript:void(0)" class="hiraola-btn hiraola-btn_dark">Отправить</a>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Hiraola's Single Product Tab Area End Here -->



        <!-- Begin Hiraola's Product Area Two -->
        <div class="hiraola-product_area hiraola-product_area-2 ">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">

                        <div class="hiraola-section_title">
                            <h4>Special Offer</h4>
                        </div>


                    </div>
                    <div class="col-lg-12">
                        <div class="hiraola-product_slider-3">
                            <?php $__currentLoopData = $PageInfo['new_product']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $rating = $result['rating'];
                                    $result = $result['info'];
                                ?>
                                <!-- Begin Hiraola's Slide Item Area -->
                                <div class="slide-item">
                                    <div class="single_product">
                                        <div class="product-img">
                                            <a href="single-product.html">
                                                <?php
                                                    $images = json_decode($result->pictures);
                                                ?>
                                                <?php if(count($images) > 0): ?>
                                                    <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <img class="primary-img" src="<?php echo e($image->name); ?>" alt="<?php echo e($result->name); ?>">
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php else: ?>
                                                    <img class="primary-img" src="<?php echo e(asset('assets/images/product/medium-size/1-1.jpg')); ?>" alt="Hiraola's Product Image">
                                                <?php endif; ?>

                                            </a>
                                            <span class="sticker">New</span>
                                        </div>
                                        <div class="hiraola-product_content">
                                            <div class="product-desc_info">
                                                <h6><a class="product-name" href="single-product.html"><?php echo e($result->name); ?></a></h6>
                                                <div class="price-box">
                                                    <span class="new-price"><?php echo e($result->price); ?>₴</span>
                                                </div>
                                                <div class="additional-add_action">
                                                    <ul>
                                                        <li><a class="hiraola-add_compare" <?php if($CheckAuth['status'] == false): ?> href=" <?php echo e(Route('Page', ['page' => 'wishlist'])); ?>" <?php else: ?> onclick="AddToWish(<?php echo e($result->id); ?>)" <?php endif; ?> data-toggle="tooltip" data-placement="top" title="Добавить в избранное"><i class="ion-android-favorite-outline"></i></a></li>
                                                    </ul>
                                                </div>
                                                <div class="rating-box">
                                                    <ul>
                                                        <?php for($i = 0; $i < 5; $i++): ?>
                                                            <?php if($i < $rating): ?>
                                                                <li><i class="fa fa-star-of-david"></i></li>
                                                            <?php else: ?>
                                                                <li class="silver-color"><i class="fa fa-star-of-david"></i></li>
                                                            <?php endif; ?>
                                                        <?php endfor; ?>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- Hiraola's Slide Item Area End Here -->
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Hiraola's Product Area Two End Here -->


        <?php echo csrf_field(); ?>
        <script>
            function AddToWish(id){
                let csrf = document.getElementsByName('_token')[0].value;
                $.ajax({
                    type: 'POST',
                    url: '<?php echo e(Route("AddToWish")); ?>',
                    dataType: 'json',
                    data: 'id=' + id + '&_token=' + csrf,
                    success: function(data){
                        if(data.status == true){
                            location.reload();
                        } else {
                            alert(data.error);
                        }
                    }
                });
            }
        </script>

        
    </div>
<?php /**PATH /var/www/ch6bcde14c/www/todase.com.ua/resources/views/product/index.blade.php ENDPATH**/ ?>