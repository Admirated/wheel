<header class="header-main_area">
            <div class="header-top_area">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-5">
                            <div class="ht-left_area">
                                <div class="header-shipping_area">
                                    <ul>
                                        <li>
                                            <span>Номер телефона:</span>
                                            <a href="callto://+380661173602">(066)-117-36-02</a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-7">
                            <div class="ht-right_area">
                                <div class="ht-menu">
                                    <ul>
                                        <li><a href="javascript:void(0)">курс валют<i class="fa fa-chevron-down"></i></a>
                                            <ul class="ht-dropdown ht-currency">
                                                <?php $__currentLoopData = $currency; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <li><a href="javascript:void(0)"><?php echo e($result->name); ?>: <?php echo e($result->value); ?></a></li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </ul>
                                        </li>
                                        <!--<li><a href="javascript:void(0)">Language <i class="fa fa-chevron-down"></i></a>
                                            <ul class="ht-dropdown">
                                                <li class="active"><a href="javascript:void(0)"><img src="assets/images/menu/icon/1.jpg" alt="JB's Language Icon">English</a></li>
                                                <li><a href="javascript:void(0)"><img src="assets/images/menu/icon/2.jpg" alt="JB's Language Icon">Français</a>
                                                </li>
                                            </ul>
                                        </li>-->
                                        <li><a href="my-account.html">Мой аккаунт<i class="fa fa-chevron-down"></i></a>
                                            <ul class="ht-dropdown ht-my_account">
                                                <?php if($CheckAuth['status'] == false): ?>
                                                    <li><a href="<?php echo e(Route('Page', ['page' => 'login'])); ?>">Регистрация</a></li>
                                                    <li><a href="<?php echo e(Route('Page', ['page' => 'login'])); ?>">Авторизация</a></li>
                                                <?php else: ?>
                                                    <li><a href="<?php echo e(Route('Page', ['page' => 'cart'])); ?>">Корзина</a></li>
                                                    <li><a href="<?php echo e(Route('Page', ['page' => 'login'])); ?>">Избранное</a></li>
                                                    <li><a href="<?php echo e(Route('Page', ['page' => 'login'])); ?>">Автозаполнение</a></li>
                                                <?php endif; ?>
                                            </ul>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="header-middle_area d-none d-lg-block">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-3">
                            <div class="header-logo">
                                <a href="<?php echo e(Route('Page', ['page' => 'main'])); ?>">
                                    <img src="<?php echo e(asset('assets/images/menu/logo/logo.png')); ?>" alt="То да Сё">
                                </a>
                            </div>
                        </div>
                        <div class="col-lg-9">
                            <div class="hm-form_area">
                                <form action="#" class="hm-searchbox">
                                    <input type="text" placeholder="Введите что искать">
                                    <button class="li-btn" type="submit"><i class="fa fa-search"></i></button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="header-bottom_area header-sticky stick">
                <div class="container">
                    <div class="row">
                        <div class="col-md-4 col-sm-4 d-lg-none d-block">
                            <div class="header-logo">
                                <a href="<?php echo e(Route('Page', ['page' => 'main'])); ?>">
                                    <img src="<?php echo e(asset('assets/images/menu/logo/2.png')); ?>" alt="Hiraola's Header Logo">
                                </a>
                            </div>
                        </div>
                        <div class="col-lg-9 d-none d-lg-block position-static">
                            <div class="main-menu_area">
                                <nav>
                                    <ul>
                                        <li class="dropdown-holder"><a href="<?php echo e(Route('Page', ['page' => 'main'])); ?>">Главная</a></li>
                                        <li class="dropdown-holder"><a href="<?php echo e(Route('Page', ['page' => 'main'])); ?>">Контакты</a></li>
                                    </ul>
                                </nav>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-8 col-sm-8">
                            <div class="header-right_area">
                                <ul>
                                    <?php if($CheckAuth['status'] == true): ?>
                                        <li>
                                            <a href="<?php echo e(Route('Page', ['page' => 'wishlist'])); ?>" class="wishlist-btn">
                                                <i class="ion-android-favorite-outline"></i>
                                            </a>
                                        </li>
                                    <?php endif; ?>
                                    <li>
                                        <a href="#mobileMenu" class="mobile-menu_btn toolbar-btn color--white d-lg-none d-block">
                                            <i class="ion-navicon"></i>
                                        </a>
                                    </li>
                                    <?php if($CheckAuth['status'] == true): ?>
                                        <li>
                                            <a href="#miniCart" class="minicart-btn toolbar-btn">
                                                <i class="ion-bag"></i>
                                            </a>
                                        </li>
                                    <?php endif; ?>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php if($CheckAuth['status'] == true): ?>
                <div class="offcanvas-minicart_wrapper" id="miniCart">
                    <div class="offcanvas-menu-inner">
                        <a href="#" class="btn-close"><i class="ion-android-close"></i></a>
                        <div class="minicart-content">
                            <div class="minicart-heading">
                                <h4>Корзина</h4>
                            </div>
                            <ul class="minicart-list">
                                <?php
                                    $all_sum = 0;
                                    $cupon = $cart['cupon'];
                                ?>
                                <?php $__currentLoopData = $cart['product']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>   
                                    <?php
                                        $count = $result['count'];
                                        $result = $result['info'];
                                        $price = 0;
                                        if($result->discount != 0){
                                            $price = $result->discount;
                                        } else {
                                            $price = $result->price;
                                        }
                                        if($cupon != null){
                                            $price = $price - (($price * $cupon->percent) / 100);
                                        }
                                        $all_sum += $count*$price;
                                    ?>
                                    <li class="minicart-product" id="product_<?php echo e($result->id); ?>">
                                        <a class="product-item_remove" href="javascript:void(0)" onclick="DeleteProduct(<?php echo e($result->id); ?>, <?php echo e($price); ?>)"><i class="ion-android-close"></i></a>
                                        <div class="product-item_img">
                                            <?php
                                                $image = json_decode($result->pictures);
                                            ?>
                                            <img src="<?php if(count($image) > 0): ?> <?php echo e($image[0]->url); ?> <?php else: ?> <?php echo e(asset('assets/images/product/small-size/2-1.jpg')); ?> <?php endif; ?>" alt="Hiraola's Product Image">
                                        </div>
                                        <div class="product-item_content">
                                            <a class="product-item_title" href="shop-left-sidebar.html"><?php echo e($result->name); ?></a>
                                            <span class="product-item_quantity" id="price_<?php echo e($result->id); ?>"><?php echo e($price); ?>₴</span>
                                        </div>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                        <div class="minicart-item_total">
                            <span>Общая стоимость</span>
                            <span class="ammount" id="amount"><?php echo e($all_sum); ?>₴</span>
                        </div>
                        <div class="minicart-btn_area">
                            <a href="<?php echo e(Route('Page', ['page' => 'cart'])); ?>" class="hiraola-btn hiraola-btn_dark hiraola-btn_fullwidth">Перейти к оплате</a>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
            <?php echo csrf_field(); ?>
            <script>
                function DeleteProduct(id, price){
                    let csrf = document.getElementsByName('_token')[0].value;
                    $.ajax({
                        type: 'POST',
                        url: '<?php echo e(Route("DeleteProduct")); ?>',
                        dataType: 'json',
                        data: 'id=' + id + '&_token=' + csrf,
                        success: function(data){
                            if(data.status == true){
                                document.getElementById('product_' + id).remove();
                                let amount = parseFloat(document.getElementById('amount').innerText);
                                document.getElementById('amount').innerText = (amount - price) + "₴";
                            } else {
                                alert(data.error);
                            }
                        }
                    });
                }
            </script>
            <div class="mobile-menu_wrapper" id="mobileMenu">
                <div class="offcanvas-menu-inner">
                    <div class="container">
                        <a href="#" class="btn-close"><i class="ion-android-close"></i></a>
                        <div class="offcanvas-inner_search">
                            <form action="#" class="hm-searchbox">
                                <input type="text" placeholder="Введите что искать...">
                                <button class="search_btn" type="submit"><i class="ion-ios-search-strong"></i></button>
                            </form>
                        </div>
                        <nav class="offcanvas-navigation">
                            <ul class="mobile-menu">
                                <li class="menu-item-has-children">
                                    <a href="<?php echo e(Route('Page', ['page' => 'main'])); ?>">
                                        <span class="mm-text">Главная</span>
                                    </a>
                                    
                                </li>
                                <li class="menu-item-has-children">
                                    <a href="<?php echo e(Route('Page', ['page' => 'main'])); ?>">
                                        <span class="mm-text">Контакты</span>
                                    </a>
                                </li>
                                
                            </ul>
                        </nav>
                        <nav class="offcanvas-navigation">
                            <ul class="mobile-menu">

                                <?php if($CheckAuth['status'] == false): ?>
                                    <li class="menu-item-has-children"><a href="<?php echo e(Route('Page', ['page' => 'login'])); ?>">Регистрация</a></li>
                                    <li class="menu-item-has-children"><a href="<?php echo e(Route('Page', ['page' => 'login'])); ?>">Авторизация</a></li>
                                <?php else: ?>
                                    <li class="menu-item-has-children"><a href="<?php echo e(Route('Page', ['page' => 'cart'])); ?>">Корзина</a></li>
                                    <li class="menu-item-has-children"><a href="<?php echo e(Route('Page', ['page' => 'login'])); ?>">Избранное</a></li>
                                    <li class="menu-item-has-children"><a href="<?php echo e(Route('Page', ['page' => 'login'])); ?>">Автозаполнение</a></li>
                                <?php endif; ?>
                                
                            </ul>
                        </nav>
                    </div>
                </div>
            </div>
        </header>
<?php /**PATH /var/www/ch6bcde14c/www/todase.com.ua/resources/views/header.blade.php ENDPATH**/ ?>