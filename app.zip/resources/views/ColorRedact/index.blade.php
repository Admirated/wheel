
<div class="container" style="padding-bottom: 150px;">

    <div class="container top" style="background-color: #ffffff; height: 362px;box-shadow: 0px 4px 4px rgba(0, 0, 0, 0.25);border-radius: 11px; margin-top: 50px;">

        <div class="redact_title_buttons row " style=" margin: 0 auto!important; left: 27%; top:22px">
            <div class="redact_title_button" style="width: 69px;height: 28px;left: 210px;top: 153px;background: #ffffff;border-radius: 100px;padding-left: 15px;">
                Цвет
            </div>
            <div class="redact_title_button" style="width: 69px;height: 28px;left: 210px;top: 153px;background: #ffffff;border-radius: 100px; padding-left: 15px;">
                Текст
            </div>
        </div>
        <div class="slidecontainer" style="transform: rotate(90deg)">
            <input type="range" min="1" max="100" value="50" class="slider" id="myRange">

        </div>
        <div class="color_circle">

        </div>
    </div>

    <div class="container" style="text-align: center">
        <p style="margin-top: 25px;">Выберите цвет</p>
    </div>
    <div class="container" style="background-color: #ffffff; height: 195px;box-shadow: 0px 4px 4px rgba(0, 0, 0, 0.25);border-radius: 11px; margin-top: -15px; ">

        <div class="row">
            <div class="color_sector">
                <div style="background: #FFFFFF;" class="color_circle_small"></div>
                <div style="background: #3531FF;" class="color_circle_small"></div>
                <div style="background: #31FF45;" class="color_circle_small"></div>
                <div style="background: #A431FF;"class="color_circle_small"></div>
            </div>
            <div class="color_sector">
                <div style="background: #B90000;" class="color_circle_small"></div>
                <div style="background: #0007B9;" class="color_circle_small"></div>
                <div style="background: #00B912;" class="color_circle_small"></div>
                <div style="background: #7300B9;" class="color_circle_small"></div>

            </div>
            <div class="color_sector">
                <div style="background: #FF5A5A;" class="color_circle_small"></div>
                <div style="background: #5A61FF;" class="color_circle_small"></div>
                <div style="background: #5EFF5A;" class="color_circle_small"></div>
                <div style="background: #CA5AFF;" class="color_circle_small"></div>

            </div>
            <div class="color_sector">
                <div style="background: #FF4D00;" class="color_circle_small"></div>
                <div style="background: #00F0FF;" class="color_circle_small"></div>
                <div style="background: #FFE600;" class="color_circle_small"></div>
                <div style="background: #FF00D6;" class="color_circle_small"></div>

            </div>
            <div class="color_sector">
                <div style="background: #DB4200;" class="color_circle_small"></div>
                <div style="background: #00B3DB;" class="color_circle_small"></div>
                <div style="background: #DBC500;" class="color_circle_small"></div>
                <div style="background: #D600DB;" class="color_circle_small"></div>

            </div>
            <div class="color_sector">
                <div style="background: #FF7A41;" class="color_circle_small"></div>
                <div style="background: #41FFF4;" class="color_circle_small"></div>
                <div style="background: #FBFF41;" class="color_circle_small"></div>
                <div style="background: #FF41F7;" class="color_circle_small"></div>

            </div>
            <div class="color_sector">
                <div style="background: #FF988A;" class="color_circle_small"></div>
                <div style="background: #8AC7FF;" class="color_circle_small"></div>
                <div style="background: #A1FF8A;" class="color_circle_small"></div>
                <div style="background: #C58AFF;" class="color_circle_small"></div>

            </div>
            <div class="color_sector">
                <div style="background: #FFAD8A;" class="color_circle_small"></div>
                <div style="background: #BBFFF3;" class="color_circle_small"></div>
                <div style="background: #FFF38A;" class="color_circle_small"></div>
                <div style="background: #FD8AFF;" class="color_circle_small"></div>

            </div>
        </div>
    </div>
    <div class="container" style="padding-top: 25px; justify-content: center; display: flex">
        <button class="succes_add_button ">
            Coхранить
        </button>
    </div>
</div>
