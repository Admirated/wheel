<footer class="footer">
    <div class="row justify-content-between">
        <img class="footer_atribute" src="{{asset('assets/images/first_footer_atribute.png')}}">
        <img class="footer_atribute" src="{{asset('assets/images/second_footer_atribute.png')}}">
        <img class="footer_atribute" src="{{asset('assets/images/third_footer_atribute.png')}}">
        <img class="footer_atribute" src="{{asset('assets/images/fourth_footer_atribute.png')}}">
    </div>
</footer>
