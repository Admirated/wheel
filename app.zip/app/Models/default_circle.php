<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class default_circle extends Model
{
    //
}
